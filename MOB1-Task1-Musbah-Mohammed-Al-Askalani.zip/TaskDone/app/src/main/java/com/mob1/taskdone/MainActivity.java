package edu.mob1.taskdone;
import android.app.Activity;import android.os.Bundle;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.content.res.Configuration;import android.util.TypedValue;import android.view.Gravity;import android.view.View;import android.widget.*;

public class MainActivity extends Activity {
 int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
 int color(int attr){TypedValue t=new TypedValue();getTheme().resolveAttribute(attr,t,true);return t.data;}
 TextView text(String s,int size,boolean bold,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);return v;}
 GradientDrawable bg(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setGravity(Gravity.CENTER);l.setPadding(dp(24),dp(24),dp(24),dp(24));return l;}
 void add(LinearLayout p,View v,int h){LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(-1,h<0?h:dp(h));q.setMargins(0,dp(8),0,dp(8));p.addView(v,q);}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(color(android.R.attr.colorBackground));getWindow().setNavigationBarColor(color(android.R.attr.colorBackground)); boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES; if(!dark){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);} int surface=color(android.R.attr.colorBackground),fg=color(android.R.attr.textColorPrimary),muted=color(android.R.attr.textColorSecondary); LinearLayout root=col();root.setBackgroundColor(surface); setContentView(root);
 TextView check=text("✓",64,true,Color.WHITE);check.setBackground(bg(0xFF4CAF50,100));add(root,check,112);add(root,text("All tasks completed",18,true,dark?Color.WHITE:0xFF222222),38);add(root,text("Nice work!",16,false,dark?Color.WHITE:0xFF222222),32); }}
